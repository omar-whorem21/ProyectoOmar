/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dba;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author Usuario
 */
public class Metodos_sql {
    
    public static MYSQL conexion = new MYSQL();
    
    public static PreparedStatement sentencia_preparada;
    public static ResultSet resultado;
    public static String sql;
    public static int resultado_numero = 0;
    
    public int guardarUsuario(String cod_SIS, String nombre, String apellidos, String direccion, 
                       String telefono, String correo, String contraseña){
        
        int resultado = 0;
        Connection conexion = null;
        
        String sentencia_guardar = ("INSERT INTO estudiante(codigo_SIS, nombre,apellidos,direccion,telefono,correo_Institucional,contraseña) VALUE (?,?,?,?,?,?,?)");
        
        try {
            conexion = MYSQL.getConnection();
            sentencia_preparada = conexion.prepareStatement(sentencia_guardar);
            sentencia_preparada.setString(1, cod_SIS);
            sentencia_preparada.setString(2, nombre);
            sentencia_preparada.setString(3, apellidos);
            sentencia_preparada.setString(4, direccion);
            sentencia_preparada.setString(5, telefono);
            sentencia_preparada.setString(6, correo);
            sentencia_preparada.setString(7, contraseña);
            
            resultado = sentencia_preparada.executeUpdate();
            sentencia_preparada.close();
            
            conexion.close();
            
        } catch (Exception e) {
            
            System.err.println(e);
        }
        return resultado;
    }
    
   
    
    
    public static String buscarUsuarioRegistrado(String codigo_SIS, String Contraseña){
        String busqueda_usuario = null;
        Connection conexion = null;
        
        try {
            conexion = MYSQL.getConnection();
            String sentencia_buscar_usuario = ("SELECT codigo_SIS, contraseña FROM estudiante WHERE codigo_SIS = '"+codigo_SIS+"' && contraseña = '"+ Contraseña +"' ");
            sentencia_preparada = conexion.prepareStatement(sentencia_buscar_usuario);
            resultado = sentencia_preparada.executeQuery();
            if(resultado.next()){
                busqueda_usuario = "usuario encontrado";
            }else{
                busqueda_usuario = "usuario no encontrado";
            }
            
            conexion.close();
            
        } catch (Exception e) {
            System.out.println(e);
        }
        return busqueda_usuario;
    }

    public static String buscarAdmRegistrado(String admi, String Contraseña){
        
        String busqueda_usuario = null;
        Connection conexion = null;
        
        try {
            conexion = MYSQL.getConnection();
            String sentencia_buscar_usuario = ("SELECT administracion, contraseña FROM administracion WHERE administracion = '"+admi+"' && contraseña = '"+ Contraseña +"' ");
            sentencia_preparada = conexion.prepareStatement(sentencia_buscar_usuario);
            resultado = sentencia_preparada.executeQuery();
            if(resultado.next()){
                busqueda_usuario = "administrador encontrado";
            }else{
                busqueda_usuario = "administrador no encontrado";
            }
            
            conexion.close();
            
        } catch (Exception e) {
            System.out.println(e);
        }
        return busqueda_usuario;
    }
    public static String buscarAutoridadRegistrado(String autoridad, String Contraseña){
            String busqueda_usuario = null;
            Connection conexion = null;
        
         try {
              conexion = MYSQL.getConnection();
              String sentencia_buscar_usuario = ("SELECT autoridad, contraseña FROM autoridad WHERE autoridad = '"+autoridad+"' && contraseña = '"+ Contraseña +"' ");
             sentencia_preparada = conexion.prepareStatement(sentencia_buscar_usuario);
             resultado = sentencia_preparada.executeQuery();
             if(resultado.next()){
                 busqueda_usuario = "autoridad encontrado";
             }else{
                 busqueda_usuario = "autoridad no encontrado";
            }
            
              conexion.close();
            
         } catch (Exception e) {
                System.out.println(e);
            }
         return busqueda_usuario;
    }
    
    public static String buscarSecretariaRegistrado(String secretaria, String Contraseña){
            String busqueda_usuario = null;
            Connection conexion = null;
        
         try {
              conexion = MYSQL.getConnection();
              String sentencia_buscar_usuario = ("SELECT secretaria, contraseña FROM secretaria WHERE secretaria = '"+secretaria+"' && contraseña = '"+ Contraseña +"' ");
             sentencia_preparada = conexion.prepareStatement(sentencia_buscar_usuario);
             resultado = sentencia_preparada.executeQuery();
             if(resultado.next()){
                 busqueda_usuario = "secretaria encontrado";
             }else{
                 busqueda_usuario = "secretaria no encontrado";
            }
            
              conexion.close();
            
         } catch (Exception e) {
                System.out.println(e);
            }
         return busqueda_usuario;
    }
    
    public static String buscarTribunalRegistrado(String tribunal, String Contraseña){
            String busqueda_usuario = null;
            Connection conexion = null;
        
         try {
              conexion = MYSQL.getConnection();
              String sentencia_buscar_usuario = ("SELECT tribunal, contraseña FROM tribunal WHERE tribunal = '"+tribunal+"' && contraseña = '"+ Contraseña +"' ");
             sentencia_preparada = conexion.prepareStatement(sentencia_buscar_usuario);
             resultado = sentencia_preparada.executeQuery();
             if(resultado.next()){
                 busqueda_usuario = "tribunal encontrado";
             }else{
                 busqueda_usuario = "tribunal no encontrado";
            }
            
              conexion.close();
            
         } catch (Exception e) {
                System.out.println(e);
            }
         return busqueda_usuario;
    }
    
    
    
    public static int PostularPizarra(String item, String cantidad,String hrs_academicas, String destino, String Cod_SIS, int habilitado){
        int resultado = 0;
        Connection conexion = null;
        
        String sentencia_guardar = ("INSERT INTO pizarron(item, cantidad,hrs_academicas,destino,cod_SIS_pizarra,habilitado) VALUE (?,?,?,?,?,?)");
        
        try {
            conexion = MYSQL.getConnection();
            sentencia_preparada = conexion.prepareStatement(sentencia_guardar);
            sentencia_preparada.setString(1, item);
            sentencia_preparada.setString(2, cantidad);
            sentencia_preparada.setString(3, hrs_academicas);
            sentencia_preparada.setString(4, destino);
            sentencia_preparada.setString(5, Cod_SIS);
            sentencia_preparada.setInt(6, habilitado);
           
            
            resultado = sentencia_preparada.executeUpdate();
            sentencia_preparada.close();
            
            conexion.close();
            
        } catch (Exception e) {
            
            System.err.println(e);
        }
        return resultado;
    }
    
    public static int PostularLaboratorio(String item, String cantidad,String hrs_academicas, String auxiliatura, String codigo_aux, String Cod_SIS, int habilitado){
        int resultado = 0;
        Connection conexion = null;
        
        String sentencia_guardar = ("INSERT INTO laboratorio(item, cantidad,hrs_academicas, auxiliatura, codigo_aux, cod_SIS_lab, habilitado) VALUE (?,?,?,?,?,?,?)");
        
        try {
            conexion = MYSQL.getConnection();
            sentencia_preparada = conexion.prepareStatement(sentencia_guardar);
            sentencia_preparada.setString(1, item);
            sentencia_preparada.setString(2, cantidad);
            sentencia_preparada.setString(3, hrs_academicas);
            sentencia_preparada.setString(4, auxiliatura);
            sentencia_preparada.setString(5, codigo_aux);
            sentencia_preparada.setString(6, Cod_SIS);
            sentencia_preparada.setInt(7, habilitado);
            
           
            
            resultado = sentencia_preparada.executeUpdate();
            sentencia_preparada.close();
            
            conexion.close();
            
        } catch (Exception e) {
            
            System.err.println(e);
        }
        return resultado;
    }
    
    
    
    public int guardarAutoridad(String nombre, String apellidos, String autoridad, String contraseña){
        
        int resultado = 0;
        Connection conexion = null;
        
        String sentencia_guardar = ("INSERT INTO autoridad(nombre,apellidos,autoridad,contraseña) VALUE (?,?,?,?)");
        
        try {
            conexion = MYSQL.getConnection();
            sentencia_preparada = conexion.prepareStatement(sentencia_guardar);
            sentencia_preparada.setString(1, nombre);
            sentencia_preparada.setString(2, apellidos);
            sentencia_preparada.setString(3, autoridad);
            sentencia_preparada.setString(4, contraseña);
            
            resultado = sentencia_preparada.executeUpdate();
            sentencia_preparada.close();
            
            conexion.close();
            
        } catch (Exception e) {
            
            System.err.println(e);
        }
        return resultado;
    }
    
    
    public int guardarSecretaria(String nombre, String apellidos, String secretaria, String contraseña){
        
        int resultado = 0;
        Connection conexion = null;
        
        String sentencia_guardar = ("INSERT INTO secretaria(nombre,apellidos,secretaria,contraseña) VALUE (?,?,?,?)");
        
        try {
            conexion = MYSQL.getConnection();
            sentencia_preparada = conexion.prepareStatement(sentencia_guardar);
            sentencia_preparada.setString(1, nombre);
            sentencia_preparada.setString(2, apellidos);
            sentencia_preparada.setString(3, secretaria);
            sentencia_preparada.setString(4, contraseña);
            
            resultado = sentencia_preparada.executeUpdate();
            sentencia_preparada.close();
            
            conexion.close();
            
        } catch (Exception e) {
            
            System.err.println(e);
        }
        return resultado;
    }
    public int guardarTribunal(String nombre, String apellidos, String tribunal, String contraseña){
        
        int resultado = 0;
        Connection conexion = null;
        
        String sentencia_guardar = ("INSERT INTO tribunal(nombre,apellidos,tribunal,contraseña) VALUE (?,?,?,?)");
        
        try {
            conexion = MYSQL.getConnection();
            sentencia_preparada = conexion.prepareStatement(sentencia_guardar);
            sentencia_preparada.setString(1, nombre);
            sentencia_preparada.setString(2, apellidos);
            sentencia_preparada.setString(3, tribunal);
            sentencia_preparada.setString(4, contraseña);
            
            resultado = sentencia_preparada.executeUpdate();
            sentencia_preparada.close();
            
            conexion.close();
            
        } catch (Exception e) {
            
            System.err.println(e);
        }
        return resultado;
    }
    
    public int guardarAdmi(String nombre, String apellidos, String administracion, String contraseña){
        
        int resultado = 0;
        Connection conexion = null;
        
        String sentencia_guardar = ("INSERT INTO administracion(nombre,apellidos,administracion,contraseña) VALUE (?,?,?,?)");
        
        try {
            conexion = MYSQL.getConnection();
            sentencia_preparada = conexion.prepareStatement(sentencia_guardar);
            sentencia_preparada.setString(1, nombre);
            sentencia_preparada.setString(2, apellidos);
            sentencia_preparada.setString(3, administracion);
            sentencia_preparada.setString(4, contraseña);
            
            resultado = sentencia_preparada.executeUpdate();
            sentencia_preparada.close();
            
            conexion.close();
            
        } catch (Exception e) {
            
            System.err.println(e);
        }
        return resultado;
    }
    
    public static String buscarMateriaRegistrada(String abrev,String tabla, String codigo_SIS, String Item){
        String busqueda_usuario = null;
        Connection conexion = null;
        
        try {
            conexion = MYSQL.getConnection();
            String sentencia_buscar_usuario = ("SELECT cod_SIS_"+abrev+", item FROM "+tabla+" WHERE cod_SIS_"+abrev+" = '"+codigo_SIS+"' && item = '"+ Item +"' ");
            sentencia_preparada = conexion.prepareStatement(sentencia_buscar_usuario);
            resultado = sentencia_preparada.executeQuery();
            if(resultado.next()){
                busqueda_usuario = "materia encontrada";
            }else{
                busqueda_usuario = "materia no encontrada";
            }
            
            conexion.close();
            
        } catch (Exception e) {
            System.out.println(e);
        }
        return busqueda_usuario;
    }
}
